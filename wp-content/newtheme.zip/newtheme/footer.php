</div> <!-- Closing #content -->
    <footer class="site-footer">
        <div class="footer-wrapper">
            <div class="container footer-section-1">
                <div class="row">
                <div class="col-md-4">
                <div class="footer-logo">
                <a href="<?php echo home_url(); ?>">
                <img src="<?php echo esc_url( get_template_directory_uri() . '/Assets/Images/broadwaycitylogo.png' ); ?>" alt="BroadwayCity UK" >
                </a>
                </div>
            </div>
                    <div class="col-md-2 footer-block">
                        <p class=footer_headinginfo>Phone UK</p>
                        <p>0333 444 0222</p>
                    </div>    
                    <div class="col-md-2 footer-block">
                        <p class=footer_headinginfo>Email</p>
                        <p>info@broadwaycity.co.uk</p>
                    </div>    
                    <div class="col-md-4">
                        <p class=footer_headinginfo>Our Address</p>
                        <p>The Future Works Building 2-Brunel Way, Slough</p>
                    </div>    
                </div>
            </div>                
            </div>
                
            <div class="container footer-section-2">
                <div class="row">
                    <div class="col-md-6">
                        <ul class="forthe-footer">
                             <li class="for-footer">
                                <p class="footer-sec2">Blogs</p>
                            </li>
                            <li class="for-footer">
                                <p class="footer-sec2">Tearms of Use</p>
                            </li>
                            <li class="for-footer">
                                <p class="footer-sec2">Privacy Note</p>
                            </li>
                            <li class="for-footer">
                                <p class="footer-sec2">Disclaimer</p>
                            </li>
                        </ul>
                    </div>
                    <div class="col-md-6">
                        <p>BROADWAY CITY (UK) LTD Company Number 13538415</p>
                    </div>
                </div>
            </div>

            <div class="container footer-section-3">
                <div class="row">
                    <div class="col-md-6">
                        <div class="footer-bottom">
                            <p>&copy; 2024 Broadway City Gwadar. All rights reserved.</p>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="footer-social">
                            <a href="https://www.facebook.com/BCG-UK-Broadway-City-Gwadar-111507234737934/"><img src="<?php echo esc_url( get_template_directory_uri() . '/Assets/Images/icons8-facebook.svg' ); ?>" alt="Facebook" ></a>
                            <a href="https://www.instagram.com/bcgukltd/"><img src="<?php echo esc_url( get_template_directory_uri() . '/Assets/Images/icons8-instagram.svg' ); ?>" alt="Instagram" ></a>
                            <a href="https://www.linkedin.com/company/bcg-uk-broadway-city-gwadar"><img src="<?php echo esc_url( get_template_directory_uri() . '/Assets/Images/icons8-linkedin.svg' ); ?>" alt="Linkdin" ></a>   
                         </div>
                    </div>
                </div>
            </div>
        
    </footer>
    <?php wp_footer(); ?>
</body>
</html>
