<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <meta name="description" content="Gwadar serves as the focal point of the China-Pakistan Economic Corridor (CPEC), a game-changer in regional trade and commerce. Gwadar city’s strategic">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Broadway City UK</title>
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<header class="site-header">
    <div class="header-wrapper">
        <div class="logo">
            <a href="<?php echo home_url(); ?>">
                <img src="<?php echo esc_url( get_template_directory_uri() . '/Assets/Images/broadwaycitylogo.png' ); ?>" alt="Broadway City Gwadar">
            </a>
        </div>
        <nav class="main-navigation">
            <?php
            wp_nav_menu( array(
                'theme_location' => 'main-menu',
                'container' => 'ul',
                'menu_class' => 'nav-menu',
            ) );
            ?>
        </nav>
        <div class="cta-button">
            <a href="#" class="button">50% Cashback Offer</a>
        </div>
        <!-- Hamburger Menu for Mobile -->
        <div class="mobile-menu-icon">
            <span></span>
            <span></span>
            <span></span>
        </div>
    </div>
</header>