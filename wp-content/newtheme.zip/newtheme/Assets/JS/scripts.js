document.addEventListener('DOMContentLoaded', function () {
    const mobileMenuIcon = document.querySelector('.mobile-menu-icon');
    const navMenu = document.querySelector('.nav-menu');

    mobileMenuIcon.addEventListener('click', function () {
        navMenu.classList.toggle('open');
    });
});
