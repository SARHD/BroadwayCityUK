<?php
function register_custom_menu() {
    register_nav_menu('main-menu', __('Main Menu'));
}
add_action('init', 'register_custom_menu');
?>

<?php
function enqueue_custom_styles() {
    wp_enqueue_style('main-style', get_template_directory_uri() . '/Assets/CSS/style.css');
    wp_enqueue_style('header-style', get_template_directory_uri() . '/Assets/CSS/Header.css');
    wp_enqueue_style('footer-style', get_template_directory_uri() . '/Assets/CSS/Footer.css');
}
add_action('wp_enqueue_scripts', 'enqueue_custom_styles');
?>


<?php function mytheme_register_menus() {
    register_nav_menus( array(
        'main-menu' => __( 'Main Menu', 'mytheme' ),
    ) );
}
add_action( 'init', 'mytheme_register_menus' );
?>

<?php
function custom_theme_bootstrap() {
    //wp_enqueue_style( 'bootstrap-css', 'https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css', array(), '4.5.2' );
    wp_enqueue_style('bootstrap-css', get_template_directory_uri() . '/Assets/CSS/bootstrap.min.css');
    //wp_enqueue_script( 'bootstrap-js', 'https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js', array( 'jquery' ), '4.5.2', true );
    wp_enqueue_script('bootstrap-js', get_template_directory_uri() . '/Assets/JS/bootstrap.bundle.min.js');
    wp_enqueue_script( 'popper-js', 'https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.1/umd/popper.min.js', array( 'jquery' ), '1.16.1', true );
}
add_action( 'wp_enqueue_scripts', 'custom_theme_bootstrap' );
?>

<?php
function custom_theme_scripts() {
    wp_enqueue_script('custom-scripts', get_template_directory_uri() . '/Assets/JS/scripts.js', array(), null, true);
}
add_action('wp_enqueue_scripts', 'custom_theme_scripts');

?>